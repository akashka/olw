import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { IndentPage } from './indent';

@NgModule({
  declarations: [
    IndentPage,
  ],
  imports: [
    IonicPageModule.forChild(IndentPage),
  ],
})
export class IndentPageModule {}
 